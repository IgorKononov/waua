# waua
The "ualangpack" for My Lang app
Webasyst Apps, Plugins and Widgets Ukrainian Translation
