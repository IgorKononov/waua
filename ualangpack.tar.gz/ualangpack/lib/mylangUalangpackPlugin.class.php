<?php

class mylangUalangpackPlugin extends mylangPlugin
{

}
