<?php
  return array (
    'apps' => 
      array (
        'shop' => 
          array (
            'version' => '8.4.5',
            'plugins' => 
              array (
                'cml1c' => 
                    array (
                      'version' => '2.5.8',
                          ),        
                'migrate' => 
                    array (
                      'version' => '2.1.1',
                          ),
                'redirect' =>
                    array (
                      'version' => '1.1',
                          ),        
                'yandexmarket' => 
                    array (
                      'version' => '2.3.3',
                          ),
                'referrals' => 
                    array (
                      'version' => '1.1.3',
                          ),
                'watermark' => 
                    array (
                      'version' => '2.0.0',
                          ),
                'paypal' => 
                    array (
                      'version' => '1.0.4',
                          ),
                'brands' => 
                    array (
                      'version' => '1.1',
                          ),
                'invoice' => 
                    array (
                      'version' => '1.0.2',
                          ),
                 'favoriteproducts' => 
                    array (
                      'version' => '1.0.0',
                          ),   
                  ),      
              ),
        'crm' => 
          array (
            'version' => '1.4.1',
            'plugins' => 
              array (
                'telegram' => 
                  array (
                    'version' => '1.0.3',
                        ),
                    'fb' => 
                        array (
                          'version' => '1.0.3',
                              ),    
                    'vk' => 
                        array (
                          'version' => '1.0.4',
                              ),
                    'zadarma' => 
                        array (
                          'version' => '1.0.0',
                              ),
                     'telphin' => 
                        array (
                          'version' => '1.1.0',
                              ),
                      'twitter' => 
                        array (
                          'version' => '1.0.1',
                              ),
                      'sipuni' => 
                        array (
                          'version' => '1.0.0',
                              ),
                        'atolonline' => 
                        array (
                          'version' => '1.0.3',
                              ),
                        'mango' => 
                        array (
                          'version' => '1.0.1',
                              ), 
                        'imap' => 
                        array (
                          'version' => '1.0.1',
                              ),
                    ),
                  ),
        'files' => 
            array (
              'version' => '1.1.3',
              'plugins' => 
                array (
                  'dropbox' => 
                    array (
              'version' => '1.0.40',
                          ),
                  'migrate' => 
                    array (
                        'version' => '1.0',
                          ),
                  'webdav' => 
                    array (
                        'version' => '1.0',
                            ),
                  'googledrive' => 
                    array (
                        'version' => '1.0',
                          ),       
                        ),
                  ),  
        'blog' => 
          array (
            'version' => '1.4.2',
            'plugins' => 
              array (
                'import' => 
                  array (
                    'version' => '1.2',
                        ),
                'category' => 
                    array (
                      'version' => '1.2',
                          ),
                 'favorite' => 
                    array (
                      'version' => '1.0.0',   
                          ),
                  'akismet' => 
                    array (
                      'version' => '1.0.0',   
                          ),
                  'tag' => 
                    array (
                      'version' => '1.0.0',   
                          ),
                  'troll' => 
                    array (
                      'version' => '1.0',
                          ),
                  'myposts' => 
                    array (
                      'version' => '1.0.0',
                          ),
                  'emailsubscription' => 
                    array (
                      'version' => '1.0.0',
                          ),
                  'gravatar' => 
                    array (
                      'version' => '1.0.0',
                          ),
                  'markdown' => 
                    array (
                      'version' => '1.5.0',
                          ),          
                      ),
                   ),
        'photos' => 
          array (
            'version' => '1.2.10',
            'plugins' => 
              array (
                'imageeffects' => 
                    array (
                      'version' => '1.0.0',
                          ),
                'import' => 
                    array (
                      'version' => '1.0.0',
                          ),
                 'watermark' => 
                    array (
                      'version' => '1.0.0',
                          ),
                   'comments' => 
                    array (
                      'version' => '1.0.0',
                          ),
                    'publicgallery' => 
                    array (
                      'version' => '1.0.1',
                          ),   
                    ),
                ),
        'team' => 
        array (
          'version' => '1.0.10',
          'plugins' => 
            array (
              'googlecalendar' => 
                  array (
                    'version' => '1.0.19',
                        ),
              'caldav' => 
                  array (
                    'version' => '1.1.0',
                        ),
              'office365' => 
                  array (
                    'version' => '1.0.5',
                        ),
              'ics' => 
                  array (
                    'version' => '1.1.0',
                        ),    
                ),
              ),
        'mailer' => 
        array (
          'version' => '1.0.20',
              ),
        'helpdesk' => 
        array (
          'version' => '1.2.7',
              ),
        'hub' => 
        array (
          'version' => '1.2.4',
              ),
        'tasks' => 
        array (
          'version' => '1.2.0',
              ),
        'site' => 
        array (
          'version' => '2.5.9',
              ),
        'installer' => 
        array (
          'version' => '1.11.6',
              ),
        'hosting' => 
        array (
          'version' => '1.0.2',
              ),
        'webasyst' => 
          array (
            'version' => '1.11.6',
            'plugins' => 
              array (
                'cash' => 
                  array (
                    'version' => '1.0.0',
                        ),        
                    'yandexmoney' => 
                        array (
                    'version' => '1.4.1',
                        ),
                    'courier' =>
                        array (
                    'version' => '1.4.0',
                        ),    
                    'pickup' => 
                        array (
                    'version' => '1.0.0',        
                      ),
                    'sd' => 
                        array (
                    'version' => '1.0.3',
                        ),
                    'flatrate' => 
                        array (
                    'version' => '1.1.1.6',
                        ),
                      ),
                    ),
        'contacts' => 
          array (
            'version' => '1.1.6',
          ),
        'checklists' => 
        array (
          'version' => '1.0.11',
              ),
        'stickies' => 
        array (
          'version' => '1.1.1',
              ),                  
        'logs' => 
        array (
          'version' => '1.1.2',
              ),      
        'mylang' => 
        array (
          'version' => '2.5',
              ),
        'pocketlists' => 
        array (
          'version' => '3.3.0',
              ),                    
            ),
          );