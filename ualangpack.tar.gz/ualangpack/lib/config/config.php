<?php
  return array (
    'apps' => 
      array (
        'shop' => 
          array (
            'version' => '8.10.0',
            'plugins' => 
              array (
                'cml1c' => 
                    array (
                      'version' => '2.5.13',
                          ),        
                'migrate' => 
                    array (
                      'version' => '2.1.1',
                          ),
                'redirect' =>
                    array (
                      'version' => '1.1',
                          ),        
                'yandexmarket' => 
                    array (
                      'version' => '2.3.10',
                          ),
                'referrals' => 
                    array (
                      'version' => '1.1.5',
                          ),
                'watermark' => 
                    array (
                      'version' => '2.0.0',
                          ),
                'paypal' => 
                    array (
                      'version' => '1.0.6',
                          ),
                'brands' => 
                    array (
                      'version' => '1.3.0',
                          ),
                'invoice' => 
                    array (
                      'version' => '1.0.2',
                          ),
                 'favoriteproducts' => 
                    array (
                      'version' => '1.0.0',
                          ),
                    array (
                  'ordersfilter' => '2.20.1',
                  		  ),      
              ),
        'crm' => 
          array (
            'version' => '1.4.6',
            'plugins' => 
              array (
                'telegram' => 
                  array (
                    'version' => '1.0.4',
                        ),
                    'fb' => 
                        array (
                          'version' => '1.0.5',
                              ),    
                    'vk' => 
                        array (
                          'version' => '1.0.5',
                              ),
                    'zadarma' => 
                        array (
                          'version' => '1.0.1',
                              ),
                     'telphin' => 
                        array (
                          'version' => '1.1.1',
                              ),
                      'twitter' => 
                        array (
                          'version' => '1.0.2',
                              ),
                      'sipuni' => 
                        array (
                          'version' => '1.0.0',
                              ),
                        'atolonline' => 
                        array (
                          'version' => '1.0.4',
                              ),
                        'mango' => 
                        array (
                          'version' => '1.0.1',
                              ), 
                        'imap' => 
                        array (
                          'version' => '1.0.1',
                              ),
                    ),
                  ),
        'files' => 
            array (
              'version' => '1.1.4',
              'plugins' => 
                array (
                  'dropbox' => 
                    array (
              'version' => '1.1.0',
                          ),
                  'migrate' => 
                    array (
                        'version' => '1.0',
                          ),
                  'webdav' => 
                    array (
                        'version' => '1.0',
                            ),
                  'googledrive' => 
                    array (
                        'version' => '1.0',
                          ),       
                        ),
                  ),  
        'blog' => 
          array (
            'version' => '1.4.2',
            'plugins' => 
              array (
                'import' => 
                  array (
                    'version' => '1.2',
                        ),
                'category' => 
                    array (
                      'version' => '1.2',
                          ),
                 'favorite' => 
                    array (
                      'version' => '1.0.0',   
                          ),
                  'akismet' => 
                    array (
                      'version' => '1.0.0',   
                          ),
                  'tag' => 
                    array (
                      'version' => '1.0.0',   
                          ),
                  'troll' => 
                    array (
                      'version' => '1.0',
                          ),
                  'myposts' => 
                    array (
                      'version' => '1.0.0',
                          ),
                  'emailsubscription' => 
                    array (
                      'version' => '1.1.2',
                          ),
                  'gravatar' => 
                    array (
                      'version' => '1.0.0',
                          ),
                  'markdown' => 
                    array (
                      'version' => '1.5.0',
                          ),          
                      ),
                   ),
        'photos' => 
          array (
            'version' => '1.2.8',
            'plugins' => 
              array (
                'imageeffects' => 
                    array (
                      'version' => '1.0.0',
                          ),
                'import' => 
                    array (
                      'version' => '1.0.0',
                          ),
                 'watermark' => 
                    array (
                      'version' => '1.0.0',
                          ),
                   'comments' => 
                    array (
                      'version' => '1.0.0',
                          ),
                    'publicgallery' => 
                    array (
                      'version' => '1.0.1',
                          ),   
                    ),
                ),
        'team' => 
        array (
          'version' => '1.0.11',
          'plugins' => 
            array (
              'googlecalendar' => 
                  array (
                    'version' => '1.0.19',
                        ),
              'caldav' => 
                  array (
                    'version' => '1.1.0',
                        ),
              'office365' => 
                  array (
                    'version' => '1.0.5',
                        ),
              'ics' => 
                  array (
                    'version' => '1.1.0',
                        ),    
                ),
              ),
        'mailer' => 
        array (
          'version' => '1.0.21',
              ),
        'helpdesk' => 
        array (
          'version' => '1.2.9',
              ),
        'hub' => 
        array (
          'version' => '1.2.7',
              ),
        'tasks' => 
        array (
          'version' => '1.2.1',
              ),
        'site' => 
        array (
          'version' => '2.5.13',
              ),
        'installer' => 
        array (
          'version' => '1.13.8',
              ),
        'hosting' => 
        array (
          'version' => '1.0.5',
              ),
        'webasyst' => 
          array (
            'version' => '1.13.8',
            'plugins' => 
              array (
                'cash' => 
                  array (
                    'version' => '1.0.0',
                        ),        
                    'yandexmoney' => 
                        array (
                    'version' => '1.4.1',
                        ),
                    'courier' =>
                        array (
                    'version' => '1.4.7',
                        ),    
                    'pickup' => 
                        array (
                    'version' => '1.0.0',        
                      ),
                    'sd' => 
                        array (
                    'version' => '1.0.8',
                        ),
                    'boxberry' => 
                        array (
                    'version' => '1.0.6',
                        ),
                    'flatrate' => 
                        array (
                    'version' => '1.1.1',
                        ),
                      ),
                    ),
        'contacts' => 
          array (
            'version' => '1.1.6',
          ),
        'checklists' => 
        array (
          'version' => '1.0.11',
              ),
        'stickies' => 
        array (
          'version' => '1.1.1',
              ),                  
        'logs' => 
        array (
          'version' => '1.1.2',
              ),      
        'mylang' => 
        array (
          'version' => '2.7.4',
              ),
        'pocketlists' => 
        array (
          'version' => '3.5.0',
              ),                    
            ),
          );