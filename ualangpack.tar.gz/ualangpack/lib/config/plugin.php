<?php
return array (
  'name' => 'Webasyst по-украински',    
  'description'  => 'Перевод на украинский язык интерфейса продуктов Webasyst',
  'img' => 'img/ualangpack.png',
  'version' => '1.1.1',
  'vendor' => '1077750',
  'handlers' => 
  array (
  ),
    'language' => 'uk_UA'
);