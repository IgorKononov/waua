<?php
return array(    
    'app.mylang'      => array(
        'name'=>'Приложение “MyLang”',
        'strict'  => true,
        'version' => '>=2.5',
    ),
);